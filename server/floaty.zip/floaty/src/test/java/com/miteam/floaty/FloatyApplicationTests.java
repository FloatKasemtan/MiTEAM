package com.miteam.floaty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FloatyApplicationTests {

	@Test
	void contextLoads() {
	}

}
