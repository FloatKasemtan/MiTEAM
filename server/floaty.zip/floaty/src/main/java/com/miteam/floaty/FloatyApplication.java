package com.miteam.floaty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FloatyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FloatyApplication.class, args);
	}

}
